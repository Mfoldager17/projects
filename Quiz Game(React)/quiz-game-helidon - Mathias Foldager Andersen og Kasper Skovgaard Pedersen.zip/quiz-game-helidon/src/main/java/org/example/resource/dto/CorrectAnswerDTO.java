package org.example.resource.dto;

import com.fasterxml.jackson.annotation.JsonCreator;

import javax.json.bind.annotation.JsonbProperty;

public class CorrectAnswerDTO {

    private boolean correctAnswer;
    private final String explanation;
    private final String sourceURL;

    @JsonCreator
    public CorrectAnswerDTO(@JsonbProperty("correct-answer") boolean correctAnswer, @JsonbProperty("explanation") String explanation, @JsonbProperty("source_url") String sourceURL) {
        this.correctAnswer = correctAnswer;
        this.explanation = explanation;
        this.sourceURL = sourceURL;
    }

    public void setCorrectAnswer(boolean b){
        correctAnswer = b;
    }

    public boolean isCorrectAnswer() {
        return correctAnswer;
    }

    public String getExplanation() {
        return explanation;
    }

    public String getSourceURL() {
        return sourceURL;
    }

    @Override
    public String toString() {
        return "CorrectAnswerDTO{" +
                "correctAnswer=" + correctAnswer +
                ", explanation='" + explanation + '\'' +
                ", sourceURL='" + sourceURL + '\'' +
                '}';
    }
}
