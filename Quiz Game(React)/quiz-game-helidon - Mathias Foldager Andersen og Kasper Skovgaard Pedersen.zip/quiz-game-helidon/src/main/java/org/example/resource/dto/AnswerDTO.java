package org.example.resource.dto;

public class AnswerDTO {

    private final int id;
    private final String answer;

    public AnswerDTO(int id, String answer) {
        this.id = id;
        this.answer = answer;
    }

    public int getId() {
        return id;
    }

    public String getAnswer() {
        return answer;
    }

    @Override
    public String toString() {
        return "AnswerDTO{" +
                "id=" + id +
                ", answer='" + answer + '\'' +
                '}';
    }
}
