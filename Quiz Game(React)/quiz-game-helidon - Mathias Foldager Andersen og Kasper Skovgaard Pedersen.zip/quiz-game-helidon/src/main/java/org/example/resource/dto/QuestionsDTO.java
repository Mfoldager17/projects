package org.example.resource.dto;

import java.util.List;

public class QuestionsDTO {
    private final int id;
    private final String category;
    private final String field;
    private final int point;
    private final String question;
    private final List<AnswerDTO> answers;

    public QuestionsDTO(int id, String category, String field, int point, String question, List<AnswerDTO> answers) {
        this.id = id;
        this.category = category;
        this.field = field;
        this.point = point;
        this.question = question;
        this.answers = answers;
    }

    public int getId() {
        return id;
    }

    public String getCategory() {
        return category;
    }

    public String getField() {
        return field;
    }

    public int getPoint() {
        return point;
    }

    public String getQuestion() {
        return question;
    }

    public List<AnswerDTO> getAnswers() {
        return answers;
    }

    @Override
    public String toString() {
        return "QuestionsDTO{" +
                "id=" + id +
                ", category='" + category + '\'' +
                ", field='" + field + '\'' +
                ", point=" + point +
                ", question='" + question + '\'' +
                ", answers='" + answers + '\'' +
                '}';
    }
}
