package org.example.resource;

import org.example.resource.dto.CorrectAnswerDTO;
import org.example.resource.dto.QuestionsDTO;
import org.example.service.Service;

import javax.enterprise.context.ApplicationScoped;
import javax.json.JsonObject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.inject.Inject;

@ApplicationScoped
@Path("/")
public class QuestionsResource {

    private final Service service;

    @Inject
    public QuestionsResource(Service service) {
        this.service = service;
    }

    @Path("/questions/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public QuestionsDTO getQuestions(@PathParam("id") int id) {
        return service.getQuestion(id);
    }

    @Path("/questions/{id}/answer")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public CorrectAnswerDTO postAnswer(@PathParam("id") int id, JsonObject jsonObject) {
        return service.getCorrectAnswer(id, Integer.parseInt(String.valueOf(jsonObject.get("answerId"))));
    }
}
