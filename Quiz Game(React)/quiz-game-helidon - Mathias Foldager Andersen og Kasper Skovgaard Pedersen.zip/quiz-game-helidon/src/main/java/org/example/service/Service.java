package org.example.service;

import org.example.resource.dto.AnswerDTO;
import org.example.resource.dto.CorrectAnswerDTO;
import org.example.resource.dto.QuestionsDTO;

import javax.enterprise.context.Dependent;
import java.util.*;

@Dependent
public class Service {

    private final Map<Integer, QuestionsDTO> questions = new HashMap<>();
    private final Map<Integer, CorrectAnswerDTO> correctAnswers = new HashMap<>();

    public Service() {
        int id1 = 1;
        List<AnswerDTO> answers1 = Arrays.asList(new AnswerDTO(1, "Pressure"), new AnswerDTO(2, "Temperature"), new AnswerDTO(3, "Volume"), new AnswerDTO(4, "Force"), new AnswerDTO(5, "Charge"));
        QuestionsDTO questions1 = new QuestionsDTO(id1, "SCIENCE", "Physics", 12, "Which physical property can be measured in the unit Coulomb", answers1);
        questions.put(id1, questions1);

        CorrectAnswerDTO correctAnswer1 = new CorrectAnswerDTO(false, "The SI unit for electric charge is Coulomb", "https://en.wikipedia.org/wiki/Pascal_(unit)");
        correctAnswers.put(id1, correctAnswer1);
    }

    public QuestionsDTO getQuestion(int id) {
        return questions.get(id);
    }

    public CorrectAnswerDTO getCorrectAnswer(int id, int answerId){
        CorrectAnswerDTO correctAnswerDTO = correctAnswers.get(id);
        correctAnswerDTO.setCorrectAnswer(answerId == 5);
        return correctAnswerDTO;
    }
}
