import Question from './Components/Question/Question.js'

function App() {
  return (
    <div className="App">
      <Question id={1} />
    </div>
  );
}

export default App;