import React, { useState, useEffect } from 'react';
import Answer from '../Answer/Answer.js'
import './Question.css'

function Question(props) {

    const [questionData, setQuestionData] = useState({});
    const [answersData, setAnswers] = useState([]);
    const [correctAnswerData, setCorrectAnswer] = useState({});
    const [displayExplanation, setDisplayExplanation] = useState({ display: "none" });

    const rootUrl = 'http://localhost:8095'

    useEffect(() => {
        async function fetchQuestion() {
            const data = await fetchGet(rootUrl + '/questions/' + props.id)
            setQuestionData(data)
            setAnswers(data.answers)
        }
        fetchQuestion()
    }, [props.id])

    const answers = answersData.map(answer => (
        <Answer key={answer.id} answer={answer.answer} onClick={() => handleClick(answer.id)} />
    ))

    async function handleClick(id) {
        const data = await fetchPost(rootUrl + '/questions/' + props.id + '/answer', { answerId: id });
        setCorrectAnswer(data)
        setDisplayExplanation({ display: "block" });
    }

    async function fetchGet(url) {
        const response = await fetch(url, {
            method: 'GET',
            headers: { 'Content-type': 'application/json' }
        })
        return response.json();
    }

    async function fetchPost(url, data) {
        const respons = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        })
        return respons.json()
    }

    return (
        <div className="Question">
            <div className="questionHeader">
                <p>{questionData.category}</p>
                <p>{questionData.field}</p>
                <p>Points: {questionData.point}</p>
            </div>
            <div className="qAndA">
                <div className="question">{questionData.question}</div>
                {answers}
                <div id="correctAnswer" style={displayExplanation}>
                    {correctAnswerData.explanation}
                    <br></br>
                    <div>
                        Source: <a href={correctAnswerData.sourceURL}>Link to source</a>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Question;
