function Answer(props) {
    return (
        <div className="Answer" onClick={props.onClick}>
            <p>{props.answer}</p>
        </div>
    );
}

export default Answer;